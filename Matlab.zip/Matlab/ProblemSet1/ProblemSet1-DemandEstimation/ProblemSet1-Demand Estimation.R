rm(list = ls()) 
# install.packages("R.matlab")
library(R.matlab)
library(dplyr)
library(tidyverse)
library(corrplot)
dati <- readMat("/Users/giuseppe_dominici/Desktop/Problem Set of Data and Models for Managerial Decisions/Data_Broiler.mat")
dati <- as.data.frame(dati$Data.broiler)

colnames(dati) <- c("Year", "Quantity_broiler_chicken", "Income",
                    "Price_broiler_chicken", "Price_beef", "Price_corn",
                    "Price_chicken_feed", "Consumer_price_index", "Aggregate_production_chicken",
                    "US_population", "Exports_bvp", "Time_trend")

corrplot.mixed(corr = cor(dati),
                          use = "pairwise.complete.obs",
               tl.pos = "lt", tl.col = "black",tl.cex = 0.6, number.cex = 0.8)

mod1 <- lm(formula = Quantity_broiler_chicken ~ .,
           data = dati %>% dplyr::select(Quantity_broiler_chicken, Price_broiler_chicken))
summary(mod1)

mod2 <- lm(formula = Quantity_broiler_chicken ~ .,
           data = dati %>% dplyr::select(Quantity_broiler_chicken, Income, Price_beef, Consumer_price_index,
                                         Aggregate_production_chicken, US_population, Exports_bvp, Time_trend))
summary(mod2) 

emod_1_stage <-lm(formula = Price_broiler_chicken ~ . + Price_corn*Price_chicken_feed,
                    data = dati %>% dplyr::select(Price_broiler_chicken, Income, Price_corn, Price_chicken_feed, Price_beef, Consumer_price_index,
                                                  Aggregate_production_chicken, US_population, Exports_bvp, Time_trend))
summary(mod_1_stage) 

