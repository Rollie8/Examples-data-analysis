% We know that the maximum likelihoof function for both logit and probit is
% the following:
%L(θ) = sum(yi ln p(x , θ) + (1 − yi ) ln [1 − p(x , θ)])

% The only thing that changes between the two models is that:
% - for logit, the prob(y = 1|x) follows a logistic distribution function
% - for probit, the prob(y = 1|x) follows a cumulative distribution
% function of a normal distribution.

% Let's define the log-likelihood for logit:

function [LL] = LL_logit(parameters,Y,X) 
p = 1 ./ (1 + exp(-X * parameters));
% put -1 because we want to maximize log-lik while both fmincon and fminunc
% minimize the function.
LL = -1* (sum(Y .* log(p) + (1 - Y) .* log(1 - p)));
end
