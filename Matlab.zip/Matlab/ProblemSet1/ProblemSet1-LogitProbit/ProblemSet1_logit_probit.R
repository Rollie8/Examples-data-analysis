rm(list = ls()) 
# install.packages("R.matlab")
# install.packages("margins")
library(R.matlab)
library(margins)
library(dplyr)
library(tidyverse)
library(readxl)

dati <- read_excel('/Users/giuseppe_dominici/2 Semestre/Data and Models for Managerial Decisions/Problem-Set-of-Data-and-Models-for-Managerial-Decisions/ProblemSet1/ProblemSet1-LogitProbit/Dati Logit.xlsx',
                    sheet = "Sheet1")

model <- glm(SOSD ~ ., data = dati[, -5], family = binomial(link = "logit"))
summary(model)

ame <- margins(model)
summary(ame)


