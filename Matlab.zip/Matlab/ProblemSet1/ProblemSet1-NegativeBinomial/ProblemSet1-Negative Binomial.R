rm(list = ls()) 
# install.packages("R.matlab")
# install.packages("margins")
library(R.matlab)
library(margins)
library(dplyr)
library(tidyverse)
library(MASS)

dati <- readMat('/Users/giuseppe_dominici/2 Semestre/Data and Models for Managerial Decisions/Problem-Set-of-Data-and-Models-for-Managerial-Decisions/ProblemSet1/ProblemSet1-NegativeBinomial/PoissonDATA.mat')
dati <- as.data.frame(cbind(dati$Y, dati$x))

mod_nb <- glm.nb(V1~., data = dati)
summary(mod_nb)
