rm(list = ls())
library(glmnet)
library(caret)
library(readr)
library(dplyr)
library(tidyverse)
library(corrplot)
library(lmtest)
library(car)
library(cv) # for  mse and rmse computation
library("effects")
dati <- read_delim("2 Semestre/Lab of Statistics/Lab-of-Statistics/hour.csv", 
                   delim = ";", escape_double = FALSE, trim_ws = TRUE)

lbs_fun <- function(fit, offset_x=1, ...) {
  L <- length(fit$lambda)
  x <- log(fit$lambda[L])+ offset_x
  y <- fit$beta[, L]
  labs <- names(y)
  text(x, y, labels=labs, ...)
}

hist(dati$registered)
summary(dati$registered)
dati$log_registered = log(dati$registered + 1)
hist(dati$log_registered)

corrplot.mixed(corr = cor(dati %>% dplyr::select(season, yr, mnth, hr, holiday, weekday, workingday,
                                          temp, atemp, hum, windspeed, registered), use = "pairwise"),
               tl.pos = "lt", tl.col = "black",tl.cex = 0.6, number.cex = 0.8)


set.seed(15)
train.index <- createDataPartition(dati$log_registered, p = 0.8, list = FALSE)
trainingSet <- dati[train.index,]
testSet <- dati[-train.index,]

mod <- lm(log_registered ~. , 
          data = trainingSet %>% dplyr::select(season, yr, hr, holiday, weekday, workingday,
                                 temp, hum, windspeed,log_registered))
summary(mod)

vif(mod)

# Linearity plot (top-left) suggest a negative quadratic term
# Normality, homoscedasticity and outliers detection are ok
par(mfrow = c(2,2))
plot(mod)
par(mfrow = c(1,1))

rmse_test <- r2_adj <- numeric(length = 10)
results_cv <- as.data.frame(matrix(0, nrow = 10, ncol = 7))
colnames(results_cv) = list("intercept", "RMSE", "Rsquared", "MAE", "RMSESD", "RsquaredSD", "MAESD")
ctrl <- trainControl(method = "cv", number = 10)

# Use poly for polinomial regression, raw = TRUE in the options to ensure that 
# they are simply^degree, otherwise thay are orthogonal(useful to avoid multicollinearity issues)
for(i in 1:10){
  mod_poly <- lm(log_registered ~ season + yr + holiday + weekday +
                   workingday + poly(hum, i) + poly(temp, i) + poly(windspeed, i)+ poly(hr, i),
                 data = trainingSet)
  s <- summary(mod_poly)
  r2_adj[i] <- s$adj.r.squared
  
  form <- as.formula(
    paste0("log_registered ~ season + yr + holiday + weekday + workingday + ",
           "poly(hum, ", i, ") + poly(temp, ", i, ") + poly(windspeed, ", i, ") + poly(hr, ", i, ")")
  )

  cv_model <- train(form, data = trainingSet, method = "lm", trControl = ctrl)
  results_cv[i, ] <- as.matrix(cv_model$results)
  
  rmse_test[i] <- rmse(testSet$log_registered, predict(mod_poly, newdata = testSet))
}
par(mgp = c(2.5, 0.7, 0))  # Avvicina le etichette agli assi
plot(x = c(1:10), y = r2_adj, pch = 16, type = "b", 
     xlab = "Polynomial degrees", ylab = expression(R[adj]^2))

plot(x = c(1:10), y = results_cv$RMSE, pch = 16, type = "b",
     xlab = "Polynomial degrees", ylab = "RMSE",
     ylim = c(min(results_cv$RMSE,rmse_test), max(results_cv$RMSE,rmse_test)))
points(x = c(1:10), y = rmse_test, type = "b", pch = 17, col = "blue")
legend("topright", inset = 0.02,
       legend = c("CV-RMSE", "Test_RMSE"),
       lwd = 2, lty = 2:1, col = c("black", "blue"), pch = 16:17) 

mod_poly8 <- lm(log_registered ~ season + yr + holiday + weekday +
                  workingday + poly(hum, 8) + poly(temp, 8) + poly(windspeed, 8)+ poly(hr, 8),
                data = trainingSet)
par(mfrow = c(2,2))
plot(mod_poly8)
par(mfrow = c(1,1))

summary(step(mod_poly8))

pred_ols <- predict(mod_poly8, testSet)
plot(testSet$log_registered, pred_ols, xlab = "Test_response", ylab = "Predicted OLS")
abline(a =0, b =1, col = "red")
text(2,5,labels = paste("RMSE = ", round(rmse(testSet$log_registered, pred_ols), 2)), cex=1, pos=2)

rmse_train = rmse_test = numeric(10)
for(i in 1:10){
  train_x <- model.matrix(log_registered~ season + yr + holiday + weekday +
                            workingday + poly(hum, i) + poly(temp, i) + poly(windspeed, i)+ poly(hr, i) -1, data=trainingSet)
  train_y <- trainingSet$log_registered
  
  test_x <- model.matrix(log_registered~ season + yr + holiday + weekday +
                           workingday +  poly(hum, i) + poly(temp, i) + poly(windspeed, i)+ poly(hr, i)-1, data=testSet)
  test_y <- testSet$log_registered
 
  lasso <- glmnet(train_x, train_y, alpha=1)
  
  cv_lasso = cv.glmnet(x = train_x, y = train_y, alpha = 1, nfolds = 10)
  lambda_min = cv_lasso$lambda.min
  pred_lasso_test <- predict(lasso, newx = test_x, s = lambda_min)
  
  rmse_train[i] = sqrt(cv_lasso$cvm[which.min(cv_lasso$cvm)])
  rmse_test[i] = rmse(y = test_y, yhat = pred_lasso_test)
}

ylim <- range(c(rmse_train, rmse_test), na.rm = TRUE)
plot(c(1:10),rmse_train, type='b', lwd=1,
    xlab = "Polynomial degrees", ylab = 'RMSE', ylim = ylim) 
lines(x = c(1:10), y = rmse_test, type = "b", lwd=1, col="red")

legend("center", inset = 0.02,
       legend = c("Training", "Test"), 
       col = c("black", "red"), lwd = 2)

plot(lasso, xvar = "lambda", label=T)
lbs_fun(lasso)

train_x <- model.matrix(log_registered~ season + yr + holiday + weekday +
                          workingday + poly(hum, 8) + poly(temp, 8) + poly(windspeed, 8)+ poly(hr, 8) -1, data=trainingSet)
train_y <- trainingSet$log_registered
cv_lasso = cv.glmnet(x = train_x, y = train_y, alpha = 1)
abline(v=log(cv_lasso$lambda.min), col = "red", lty=2) 
plot(cv_lasso)

pred_lasso <- predict(lasso, newx = test_x, s = cv_lasso$lambda.min, xlab = "Test response", ylab = "Predicted Lasso")
plot(test_y, pred_lasso, xlab = "Test Response", ylab = "Predicted Lasso")

abline(a =0, b =1, col = "red")
text(2,7,labels = paste("RMSE = ", round(rmse(test_y, pred_lasso), 2)), cex=1, pos=2)

lasso_final <- glmnet(x = train_x, y = train_y, alpha = 1, lambda = cv_lasso$lambda.min)
coef(lasso_final)

