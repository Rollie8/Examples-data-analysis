#'Assign hex code of each centroid to the related point inside the cluster
#'
#'@param dataset The dataset containing record and attributes of your data.
#'@param clusters A vector containing the cluster assigned to each element of the dataset.
#'@param clust_name The name you want to assign to the cluster column
#'@return A list containing:
#'  \item{dataset}{The updated dataset containing clusters
#'                and centroid's hex code for each record.}
#'  \item{centroids}{The centroids and related hex code.}
hexToPoints <- function(dataset, clusters, clust_name){
  dataset$cluster <- clusters
  colnames(dataset) <- c(colnames(dataset[-ncol(dataset)]), clust_name)
  # Take only numeric variables
  numeric_data <- dataset[, sapply(dataset, is.numeric)]

  # Compute centroids
  centroids <- aggregate(numeric_data, by = list(clusters), FUN = mean)

  # Generate hex code of the centroids, the first column(group.1) is removed
  centroids$hex_code <- rgb(centroids[,-1], maxColorValue = 255)
  dataset$hex_centroid <- NA

  for(i in 1:nrow(dataset)){
    for (j in 1:nrow(centroids)) {
      if(clusters[i] == centroids[[1]][j])
        dataset$hex_centroid[i] <- centroids$hex_code[j]
    }
  }
  colnames(dataset) <- c(colnames(dataset[-ncol(dataset)]), paste("hex_centroid", clust_name, sep = "_"))
  return(list(dataset = dataset, centroids = centroids))
}

# setwd("~/MyPackageR/R")
# devtools::document() per generare la documentazione
# devtools::load_all("/Users/giuseppe_dominici/MyPackageR/R")
# per caricare le funzione su R
