#'Create a summary of the kmeans clustering using performance indicators such as
#'Sum of Square Withinss and Silhouette
#'
#'@import cluster
#'@param dataset The dataset containing record and attributes of your data.
#'@param cmax The maximum number of clusters you want to try with kmeans
#'@return A dataframe containing:
#'  \item{Clusters}{The number of clusters used in the analysis.}
#'  \item{SSW}{The SSW value related to each clustering.}
#'  \item{Silhouette}{The Silhouette Avg width value related to each clustering.}
summaryKmeans <- function(dataset, cmax){
  library(cluster)
  ClusterValidity <- data.frame(Clusters = 2:cmax,
                                   SSW = NA,
                                   Silhouette_Avg_width = NA)
  numeric_data <- dataset[, sapply(dataset, is.numeric)]
  distances <- dist(numeric_data, method = 'euclidean')
  for(i in 2:cmax){
    model <- kmeans(dataset, centers = i, nstart = 50, iter.max = 20)
    ClusterValidity$SSW[i-1] <- model$tot.withinss
    sil <- silhouette(x = model$cluster, dist = distances)
    width_cluster <- aggregate(sil, by = list(sil[, 1]), FUN = mean)
    ClusterValidity$Silhouette_Avg_width[i-1] <- sum(width_cluster[,4] * table(model$cluster))/sum(table(model$cluster))
  }
  return(ClusterValidity)
}

# setwd("~/MyPackageR/R")
# devtools::document() per generare la documentazione
# devtools::load_all("/Users/giuseppe_dominici/MyPackageR/R")
# per caricare le funzione su R
